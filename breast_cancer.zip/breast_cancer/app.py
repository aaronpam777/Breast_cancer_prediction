import streamlit as st
import pandas as pd
import joblib


# Load saved files
model = joblib.load("breast_cancer_model.pkl")
feature_names = joblib.load("feature_names.pkl")


# STEP 8.5
# Create heading
st.title("Breast Cancer Prediction")

st.write(
    "Enter the tumour measurements below and click Predict."
)


# STEP 8.9
# Create somewhere to store user inputs
input_data = {}


# STEP 8.10
# Create an input box for every feature
for feature in feature_names:

    input_data[feature] = st.number_input(
        feature,
        value=0.0
    )


# STEP 8.11
# Convert user inputs into a DataFrame
input_df = pd.DataFrame(
    [input_data],
    columns=feature_names
)


# STEP 8.12
# Create prediction button
if st.button("Predict"):

    # STEP 8.13
    # Ask model for prediction
    prediction = model.predict(input_df)[0]

    # Ask model for probabilities
    probability = model.predict_proba(input_df)[0]


    # STEP 8.14
    # Translate 0/1 into words
    if prediction == 0:

        st.success("Prediction: Benign")

    else:

        st.error("Prediction: Malignant")


    # STEP 8.15
    # Display probabilities
    st.write(
        f"Benign Probability: {probability[0]:.2%}"
    )

    st.write(
        f"Malignant Probability: {probability[1]:.2%}"
    )